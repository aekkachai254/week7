const express = require('express');
const app = express();

const port = 8080;

var id = 1630902649;
var status = "single";
var mascost = [
  {name : "sammy" , location : "LA" , birth_year : 2013 },
  {name : "tux" , location : "BKK" , birth_year : 2000 },
  {name : "Wit" , location : "CNX" , birth_year : 2020 }
];

var feature = [
   {img :"images/programming 1.jpg" , top : "Programming" , bottom : "Talk is cheepshow me the code."},{img :"images/circuit.jpg" , top : "Circuit and Electronics" , bottom : "Circuit and Electronics"}
];


var herofont = "Programming Development.";

app.set('view engine',ejs)
app.use(express.static('public'));

app.get("/get",(req,res) =>{
    res.send ("This is get methof");
})

app.get("/",(req,res) =>{
    res.render('index',{studentid : id , status : status , objmascots : mascost})
})

app.get("./index2",(req,res)=>{
  
res.render('index2',{Objfeature : feature, herofont : herofont})
})
app.listen(port,() => {
    console.log ("Server is Lisitening on port:",post)
})
